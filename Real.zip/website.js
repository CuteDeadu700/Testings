const express = require('express')
const path = require("path")
const app = express()

let arr = [];
let info = [];

app.use(express.json())
app.use(express.urlencoded({ extended:true }))
app.use(express.static('.'))

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname , 'index.html'));
})

app.post('/form-submit', (req, res) => {
  var name = req.body.name;
  var crushName = req.body.crushName;
  var data = name + " : " + crushName
  arr.push(data);
  info.length = 0;
  info.push(name , crushName)
  console.log("Got Response Successfully!!!");
  console.log(info);
  res.render('scaling.html', { 
    name: info[0],
    crushName : info[1]
  });
})

app.listen(3000, () => {
  console.log('Website is ready');
})

module.exports = arr;