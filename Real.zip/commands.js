const { Collection } = require('discord.js');
const fs = require('fs/promises');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');

class Commands {
  constructor(app) {
    this.app = app;
    this.cache = new Collection();
  }

  async load() {
    let commands = [];
    const files = await fs.readdir(`${__dirname}/commands`);

    for (const file of files) {
      const command = require(`./commands/${file}`);
      this.cache.set(command.data.name, command);
      commands.push(command.data.toJSON());
      console.log(`Loaded command ${file}`);
    }

    const rest = new REST({ version: '9' }).setToken(this.app.token);

    try {
      console.log('Refreshing global commands');

      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands },
      );

      console.log('Successfully reloaded global commands');
    } catch (err) {
      console.error(`${err.name}: ${err.message}\n${err.stack}`)
    }
  }

  listen() {
    this.app.client.on('interactionCreate', interaction => {
      if (!interaction.isCommand()) return;

      if (this.cache.has(interaction.commandName)) {
        this.cache.get(interaction.commandName)?.execute(this.app, interaction);
      }
    })
  }
}

module.exports = Commands;