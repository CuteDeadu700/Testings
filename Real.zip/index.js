const { Client, Intents } = require('discord.js');
const Commands = require('./commands.js');

class App {
  constructor(token) {
    if (!token) throw Error('Please add a bot TOKEN');

    this.token = token;

    this.client = new Client({
      intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES
      ]
    });

    this.commands = new Commands(this);
  }

  async start() {
    await this.commands.load();

    this.client.on('ready', () => {
      console.log(this.client.user.username + ' is ready');
      this.commands.listen();
    });
    //console.log(this.client);
    await this.client.login(this.token);
  }
}

let app = new App(process.env.TOKEN);
app.start();