const { SlashCommandBuilder } = require('@discordjs/builders');
const arr = require('../website.js');

function removeDuplicates(arr) {
  return arr.filter((item, index) => arr.indexOf(item) === index);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('givenames')
		.setDescription('Give Names inside array'),

  async execute(app, interaction) {
		try {
      if(!arr === [] || !arr.length == 0){
        let newArr = removeDuplicates(arr).join( "\n");

        interaction.reply(newArr);
      }
      else {
        interaction.reply('No Names Yet !!!');
      }
    } catch (err) {
      console.log(err)
		}
	}
};